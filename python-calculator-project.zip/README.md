# Python Calculator

A simple command-line calculator written in Python.

## Features
- Addition
- Subtraction
- Multiplication
- Division
- Input from terminal

## How to run

```bash
python calculator.py
```

## Purpose
This project was created as a beginner programming exercise while learning Python and basic software development concepts.
